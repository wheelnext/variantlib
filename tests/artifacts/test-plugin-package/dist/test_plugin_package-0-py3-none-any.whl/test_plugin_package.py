from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from variantlib.protocols import VariantPropertyType


@dataclass
class FeatConfig:
    name: str
    values: list[str]


namespace = "installable_plugin"


def get_all_configs(
) -> list[FeatConfig]:
    return [
        FeatConfig("feat1", ["val1c", "val1b", "val1c"]),
        FeatConfig("feat2", ["val2a", "val2b",]),
    ]


def get_supported_configs(
) -> list[FeatConfig]:
    return [
        FeatConfig("feat1", ["val1c", "val1b"]),
    ]
